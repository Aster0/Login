$('#loginButton').click(() => {

    //mp.trigger('loginToServer', "", "");

    mp.console.logInfo("example", true, true); // When pressing F11, you should now see a message saying "example"

    mp.gui.chat.push("w");
});

function test123()
{
    mp.console.logInfo("example", true, true); // When pressing F11, you should now see a message saying "example"

    mp.gui.chat.push("text");
}

mp.console.logInfo("example", true, true); // When pressing F11, you should now see a message saying "example"

