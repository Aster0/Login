let browser = mp.browsers.new("package://login.html");


mp.console.logInfo("example123", true, true); // When pressing F11, you should now see a message saying "example"
mp.events.add('loginToServer', (username, password) => {
    mp.console.logInfo("example", true, true); // When pressing F11, you should now see a message saying "example"

    browser.destroy();

});